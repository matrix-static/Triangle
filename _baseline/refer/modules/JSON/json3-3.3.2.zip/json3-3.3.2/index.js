module.exports = require("./lib/json3");
