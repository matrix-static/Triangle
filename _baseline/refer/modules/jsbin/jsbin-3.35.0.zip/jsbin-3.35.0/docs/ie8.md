# IE8 issues

## High priority

- Processor menus don't appear

## Low

- Tablular column layout issue for urls (not the shortcuts though)
- Resizing windows doesn't work

## Done

- Include jQuery and it goes to shit
- Restored panels always maximise
- Layout of profile when logged in wrong
- Dynamically change "create milestone" to "save" for first run in IE8 - then refresh should yeild a checksum
