# Two second set up

1. Install [node](http://nodejs.org)
2. From your terminal (or [command prompt](http://pcsupport.about.com/od/windows-8/a/command-prompt-windows-8.htm) if you're windows) and run:

```
    $ npm install -g jsbin
    $ jsbin
```
    
**Note:** You may have to run npm as the super user, so in that case, the first command would be:

    $ sudo npm install -g jsbin

If run the commands as the super user, you might be prompted for your password.

End end.
