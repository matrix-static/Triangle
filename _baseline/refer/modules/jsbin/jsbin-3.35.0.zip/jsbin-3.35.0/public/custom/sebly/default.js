var canvas = document.getElementById('creativejs'),
    c = canvas.getContext('2d');
